%{
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void yyerror(const char *s);
int yylex();
void print_indent(int level);
int indent = 0;
%}

%union {
    char* str;
}
%token <str> ID NUMBER
%token SWITCH CASE DEFAULT BREAK LBRACE RBRACE COLON SEMICOLON ASSIGN

%%

program:
    switch_stmt
    ;

switch_stmt:
    SWITCH '(' expr ')' LBRACE case_list RBRACE {
        print_indent(indent); printf("|-- switch_stmt\n");
        indent++;
        print_indent(indent); printf("|-- SWITCH\n");
        print_indent(indent); printf("|-- expr\n");
        indent++;
        // expr prints itself
        indent--;
        print_indent(indent); printf("|-- case_list\n");
        indent++;
        // case_list prints itself
        indent--;
        indent--;
    }
    ;

case_list:
    case_list case_stmt
    | case_stmt
    ;

case_stmt:
    CASE NUMBER COLON stmt_list BREAK SEMICOLON {
        print_indent(indent); printf("|-- case_stmt\n");
        indent++;
        print_indent(indent); printf("|-- CASE\n");
        print_indent(indent); printf("|-- NUMBER: %s\n", $2);
        print_indent(indent); printf("|-- stmt_list\n");
        indent++;
        // stmt_list prints itself
        indent--;
        print_indent(indent); printf("|-- BREAK\n");
        print_indent(indent); printf("|-- SEMICOLON\n");
        indent--;
    }
    | DEFAULT COLON stmt_list BREAK SEMICOLON {
        print_indent(indent); printf("|-- default_stmt\n");
        indent++;
        print_indent(indent); printf("|-- DEFAULT\n");
        print_indent(indent); printf("|-- stmt_list\n");
        indent++;
        // stmt_list prints itself
        indent--;
        print_indent(indent); printf("|-- BREAK\n");
        print_indent(indent); printf("|-- SEMICOLON\n");
        indent--;
    }
    ;

stmt_list:
    stmt_list stmt
    | stmt
    ;

stmt:
    ID ASSIGN expr SEMICOLON {
        print_indent(indent); printf("|-- stmt\n");
        indent++;
        print_indent(indent); printf("|-- ID: %s\n", $1);
        print_indent(indent); printf("|-- ASSIGN\n");
        print_indent(indent); printf("|-- expr\n");
        indent++;
        // expr prints itself
        indent--;
        print_indent(indent); printf("|-- SEMICOLON\n");
        indent--;
    }
    ;

expr:
    NUMBER { print_indent(indent); printf("|-- NUMBER: %s\n", $1); }
    | ID { print_indent(indent); printf("|-- ID: %s\n", $1); }
    ;

%%

void yyerror(const char *s) {
    printf("Error: %s\n", s);
}

void print_indent(int level) {
    for (int i = 0; i < level; i++) printf("    ");
}

int main() {
    printf("Enter a switch statement:\n");
    yyparse();
    return 0;
} 