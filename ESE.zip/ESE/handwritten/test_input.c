int main() {
    int x = 10;
    float y = 3.14;
    char ch = 'a';
    if (x > 5 && y < 10.0) {
        printf("x and y are within range\n");
    } else {
        printf("Out of range!\n");
    }
    return 0;
}
