#include <stdio.h>
#include <string.h>
#include <stdlib.h>

typedef struct {
    char op[5], arg1[10], arg2[10], res[10];
} Quad;

Quad quads[100];            // For optimized quadruples after copy propagation
Quad original_quads[100];   // For original quadruples before optimization
int count = 0;
int original_count = 0;

typedef struct {
    char temp[10], original[10];
} CopyTable;

CopyTable copies[100];
int cCount = 0;

void parseLine(char *line) {
    char lhs[10], a1[10], op[5], a2[10];
    if (sscanf(line, "%s = %s %s %s", lhs, a1, op, a2) == 4) {
        // Store original quadruple
        strcpy(original_quads[original_count].res, lhs);
        strcpy(original_quads[original_count].arg1, a1);
        strcpy(original_quads[original_count].op, op);
        strcpy(original_quads[original_count].arg2, a2);
        original_count++;
        
        // Store for optimization
        strcpy(quads[count].res, lhs);
        strcpy(quads[count].arg1, a1);
        strcpy(quads[count].op, op);
        strcpy(quads[count].arg2, a2);
    } else if (sscanf(line, "%s = %s", lhs, a1) == 2) {
        // Store original quadruple
        strcpy(original_quads[original_count].res, lhs);
        strcpy(original_quads[original_count].op, "=");
        strcpy(original_quads[original_count].arg1, a1);
        strcpy(original_quads[original_count].arg2, "-");
        original_count++;
        
        // Store for optimization
        strcpy(quads[count].res, lhs);
        strcpy(quads[count].op, "=");
        strcpy(quads[count].arg1, a1);
        strcpy(quads[count].arg2, "-");

        if (lhs[0] == 't' && a1[0] != 't') {
            strcpy(copies[cCount].temp, lhs);
            strcpy(copies[cCount++].original, a1);
        }
    }
    count++;
}

void applyCopyPropagation() {
    for (int i = 0; i < count; i++) {
        for (int j = 0; j < cCount; j++) {
            if (strcmp(quads[i].arg1, copies[j].temp) == 0)
                strcpy(quads[i].arg1, copies[j].original);
            if (strcmp(quads[i].arg2, copies[j].temp) == 0)
                strcpy(quads[i].arg2, copies[j].original);
        }
    }
}

void printOriginalQuadruples() {
    printf("Original Quadruples (Before Copy Propagation):\n");
    printf("%-10s%-10s%-10s%-10s\n", "Op", "Arg1", "Arg2", "Result");
    for (int i = 0; i < original_count; i++)
        printf("%-10s%-10s%-10s%-10s\n", 
               original_quads[i].op, 
               original_quads[i].arg1, 
               original_quads[i].arg2, 
               original_quads[i].res);
    printf("\n");
}

void printOptimizedQuadruples() {
    printf("Quadruples After Copy Propagation:\n");
    printf("%-10s%-10s%-10s%-10s\n", "Op", "Arg1", "Arg2", "Result");
    for (int i = 0; i < count; i++)
        printf("%-10s%-10s%-10s%-10s\n", quads[i].op, quads[i].arg1, quads[i].arg2, quads[i].res);
}

int main() {
    FILE *fp = fopen("input.txt", "r");
    if (!fp) { printf("Cannot open input.txt\n"); return 1; }

    char line[100];
    while (fgets(line, sizeof(line), fp))
        if (strlen(line) > 1) parseLine(line);
    fclose(fp);

    printOriginalQuadruples();
    applyCopyPropagation();
    printOptimizedQuadruples();
    return 0;
}