#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
    char op[5], arg1[10], arg2[10], res[10];
} Quad;

Quad quads[100];
Quad original_quads[100];  // To store original quadruples
int count = 0;
int original_count = 0;    // To count original quadruples

int findCommon(char *op, char *a1, char *a2) {
    for (int i = 0; i < count; i++)
        if (!strcmp(quads[i].op, op) &&
            ((!strcmp(quads[i].arg1, a1) && !strcmp(quads[i].arg2, a2)) ||
             (!strcmp(quads[i].arg1, a2) && !strcmp(quads[i].arg2, a1))))
            return i;
    return -1;
}

void parseLine(char *line) {
    char lhs[10], a1[10], op[5], a2[10];
    if (sscanf(line, "%s = %s %s %s", lhs, a1, op, a2) == 4) {
        // Store original quadruple
        strcpy(original_quads[original_count].op, op);
        strcpy(original_quads[original_count].arg1, a1);
        strcpy(original_quads[original_count].arg2, a2);
        strcpy(original_quads[original_count++].res, lhs);
        
        // Process for CSE
        int pos = findCommon(op, a1, a2);
        if (pos != -1) {
            strcpy(quads[count].op, "=");
            strcpy(quads[count].arg1, quads[pos].res);
            strcpy(quads[count].arg2, "-");
            strcpy(quads[count++].res, lhs);
        } else {
            strcpy(quads[count].op, op);
            strcpy(quads[count].arg1, a1);
            strcpy(quads[count].arg2, a2);
            strcpy(quads[count++].res, lhs);
        }
    }
}

void printOriginalQuadruples() {
    printf("Original Quadruples (Before CSE Optimization):\n");
    printf("%-10s%-10s%-10s%-10s\n", "Op", "Arg1", "Arg2", "Result");
    for (int i = 0; i < original_count; i++)
        printf("%-10s%-10s%-10s%-10s\n", 
               original_quads[i].op, 
               original_quads[i].arg1, 
               original_quads[i].arg2, 
               original_quads[i].res);
    printf("\n");
}

void printOptimizedQuadruples() {
    printf("Quadruples After Common Subexpression Elimination:\n");
    printf("%-10s%-10s%-10s%-10s\n", "Op", "Arg1", "Arg2", "Result");
    for (int i = 0; i < count; i++)
        printf("%-10s%-10s%-10s%-10s\n", quads[i].op, quads[i].arg1, quads[i].arg2, quads[i].res);
}

int main() {
    FILE *fp = fopen("input.txt", "r");
    if (!fp) { printf("input.txt missing\n"); return 1; }

    char line[100];
    while (fgets(line, sizeof(line), fp))
        if (strlen(line) > 1) parseLine(line);
    fclose(fp);

    printOriginalQuadruples();
    printOptimizedQuadruples();
    return 0;
}