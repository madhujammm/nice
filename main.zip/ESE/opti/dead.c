#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

typedef struct {
    char op[5], arg1[10], arg2[10], res[10];
    int isLive;
} Quad;

Quad quads[100];
int count = 0;

void parseLine(char *line) {
    char lhs[10], a1[10], op[5], a2[10];
    if (sscanf(line, "%s = %s %s %s", lhs, a1, op, a2) == 4) {
        strcpy(quads[count].res, lhs);
        strcpy(quads[count].arg1, a1);
        strcpy(quads[count].op, op);
        strcpy(quads[count].arg2, a2);
    } else if (sscanf(line, "%s = %s", lhs, a1) == 2) {
        strcpy(quads[count].res, lhs);
        strcpy(quads[count].op, "=");
        strcpy(quads[count].arg1, a1);
        strcpy(quads[count].arg2, "-");
    }
    quads[count++].isLive = 0;
}

int isUsed(char *var) {
    for (int i = 0; i < count; i++) {
        if (!strcmp(quads[i].arg1, var) || !strcmp(quads[i].arg2, var))
            return 1;
    }
    return 0;
}

void deadCodeElimination() {
    for (int i = 0; i < count; i++) {
        if (!isUsed(quads[i].res)) {
            if (quads[i].res[0] == 't') // eliminate only temporaries
                quads[i].isLive = 0;
            else
                quads[i].isLive = 1;
        } else {
            quads[i].isLive = 1;
        }
    }
}

void printAllQuadruples() {
    printf("Original Quadruples (Before Dead Code Elimination):\n");
    printf("%-10s%-10s%-10s%-10s\n", "Op", "Arg1", "Arg2", "Result");
    for (int i = 0; i < count; i++)
        printf("%-10s%-10s%-10s%-10s\n", quads[i].op, quads[i].arg1, quads[i].arg2, quads[i].res);
}

void printLiveQuadruples() {
    printf("\nQuadruples After Dead Code Elimination:\n");
    printf("%-10s%-10s%-10s%-10s\n", "Op", "Arg1", "Arg2", "Result");
    for (int i = 0; i < count; i++) {
        if (quads[i].isLive)
            printf("%-10s%-10s%-10s%-10s\n", quads[i].op, quads[i].arg1, quads[i].arg2, quads[i].res);
    }
}

int main() {
    FILE *fp = fopen("input.txt", "r");
    if (!fp) { printf("Cannot open input.txt\n"); return 1; }

    char line[100];
    while (fgets(line, sizeof(line), fp))
        if (strlen(line) > 1) parseLine(line);
    fclose(fp);

    printAllQuadruples();       // 🔍 Print before DCE
    deadCodeElimination();      // 🚫 Apply Dead Code Elimination
    printLiveQuadruples();      // ✅ Print after DCE

    return 0;
}
