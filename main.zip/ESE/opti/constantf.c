#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

typedef struct {
    char op[5], arg1[10], arg2[10], result[10];
} Quad;

Quad quads[100], folded[100];
int count = 0;

void addQuad(char *op, char *a1, char *a2, char *res) {
    strcpy(quads[count].op, op);
    strcpy(quads[count].arg1, a1);
    strcpy(quads[count].arg2, a2);
    strcpy(quads[count].result, res);
    count++;
}

void constantFolding() {
    for (int i = 0; i < count; i++) {
        if (isdigit(quads[i].arg1[0]) && isdigit(quads[i].arg2[0])) {
            int a = atoi(quads[i].arg1);
            int b = atoi(quads[i].arg2);
            int r;
            if (!strcmp(quads[i].op, "+")) r = a + b;
            else if (!strcmp(quads[i].op, "-")) r = a - b;
            else if (!strcmp(quads[i].op, "*")) r = a * b;
            else if (!strcmp(quads[i].op, "/")) r = b != 0 ? a / b : 0;

            strcpy(folded[i].op, "=");
            sprintf(folded[i].arg1, "%d", r);
            strcpy(folded[i].arg2, "-");
            strcpy(folded[i].result, quads[i].result);
        } else {
            folded[i] = quads[i];
        }
    }
}

void printQuadTable(Quad q[], int n) {
    printf("\nQuadruple Table:\n");
    printf("Op\tArg1\tArg2\tResult\n");
    for (int i = 0; i < n; i++) {
        printf("%s\t%s\t%s\t%s\n", q[i].op, q[i].arg1, q[i].arg2, q[i].result);
    }
}

void parseExpression(char *line) {
    char lhs[10], op[5], arg1[10], arg2[10];
    if (sscanf(line, "%s = %s %s %s", lhs, arg1, op, arg2) == 4) {
        addQuad(op, arg1, arg2, lhs);
    }
}

int main() {
    FILE *fp = fopen("input.txt", "r");
    if (!fp) {
        printf("Could not open input.txt\n");
        return 1;
    }

    char line[100];
    while (fgets(line, sizeof(line), fp)) {
        if (strlen(line) > 1)
            parseExpression(line);
    }
    fclose(fp);

    printf("\nOriginal Quadruples:");
    printQuadTable(quads, count);

    constantFolding();

    printf("\nAfter Constant Folding:");
    printQuadTable(folded, count);

    return 0;
}