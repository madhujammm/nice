#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

typedef struct {
    char op[5], arg1[10], arg2[10], result[10];
} Quad;

typedef struct {
    char name[10];
    int value, isConst;
} Const;

Quad quads[100];          // For optimized quadruples after constant propagation
Quad original_quads[100]; // For original quadruples before optimization
Const consts[100];
int count = 0, cCount = 0;
int original_count = 0;   // To track original quadruples count

int getConst(char *n, int *v) {
    for (int i = 0; i < cCount; i++)
        if (!strcmp(consts[i].name, n) && consts[i].isConst) {
            *v = consts[i].value;
            return 1;
        }
    return 0;
}

void setConst(char *n, int v) {
    for (int i = 0; i < cCount; i++)
        if (!strcmp(consts[i].name, n)) {
            consts[i].value = v;
            consts[i].isConst = 1;
            return;
        }
    strcpy(consts[cCount].name, n);
    consts[cCount].value = v;
    consts[cCount++].isConst = 1;
}

void parseLine(char *l) {
    char lhs[10], a1[10], op[5], a2[10];
    
    // Case 1: Arithmetic expression (t2 = t1 + 4)
    if (sscanf(l, "%s = %s %s %s", lhs, a1, op, a2) == 4) {
        // Store original
        strcpy(original_quads[original_count].result, lhs);
        strcpy(original_quads[original_count].arg1, a1);
        strcpy(original_quads[original_count].op, op);
        strcpy(original_quads[original_count].arg2, a2);
        original_count++;
        
        // Store for optimization
        strcpy(quads[count].result, lhs);
        strcpy(quads[count].arg1, a1);
        strcpy(quads[count].op, op);
        strcpy(quads[count].arg2, a2);
        count++;
    }
    // Case 2: Simple assignment (t1 = 10)
    else if (sscanf(l, "%s = %s", lhs, a1) == 2) {
        // Store original
        strcpy(original_quads[original_count].result, lhs);
        strcpy(original_quads[original_count].arg1, a1);
        strcpy(original_quads[original_count].op, "=");
        strcpy(original_quads[original_count].arg2, "-");
        original_count++;
        
        // Store for optimization
        strcpy(quads[count].result, lhs);
        strcpy(quads[count].arg1, a1);
        strcpy(quads[count].op, "=");
        strcpy(quads[count].arg2, "-");
        count++;

        // Register as constant if it's a number
        if (isdigit(a1[0]) || (a1[0] == '-' && isdigit(a1[1])))
            setConst(lhs, atoi(a1));
    }
}

void constProp() {
    for (int i = 0; i < count; i++) {
        int a, b;
        if (getConst(quads[i].arg1, &a))
            sprintf(quads[i].arg1, "%d", a);
        if (getConst(quads[i].arg2, &b))
            sprintf(quads[i].arg2, "%d", b);
        if (isdigit(quads[i].arg1[0]) && isdigit(quads[i].arg2[0])) {
            a = atoi(quads[i].arg1);
            b = atoi(quads[i].arg2);
            int res = 0;
            if (!strcmp(quads[i].op, "+")) res = a + b;
            else if (!strcmp(quads[i].op, "-")) res = a - b;
            else if (!strcmp(quads[i].op, "*")) res = a * b;
            else if (!strcmp(quads[i].op, "/") && b != 0) res = a / b;
            sprintf(quads[i].arg1, "%d", res);
            strcpy(quads[i].op, "=");
            strcpy(quads[i].arg2, "-");
            setConst(quads[i].result, res);
        }
    }
}

void printOriginalQuadruples() {
    printf("Original Quadruples (Before Constant Propagation):\n");
    printf("%-10s%-10s%-10s%-10s\n", "Op", "Arg1", "Arg2", "Result");
    for (int i = 0; i < original_count; i++)
        printf("%-10s%-10s%-10s%-10s\n", 
               original_quads[i].op, 
               original_quads[i].arg1, 
               original_quads[i].arg2, 
               original_quads[i].result);
    printf("\n");
}

void printOptimizedQuadruples() {
    printf("Quadruples After Constant Propagation:\n");
    printf("%-10s%-10s%-10s%-10s\n", "Op", "Arg1", "Arg2", "Result");
    for (int i = 0; i < count; i++)
        printf("%-10s%-10s%-10s%-10s\n", quads[i].op, quads[i].arg1, quads[i].arg2, quads[i].result);
}

int main() {
    FILE *fp = fopen("input.txt", "r");
    if (!fp) {
        printf("File error!\n");
        return 1;
    }
    char line[100];
    while (fgets(line, sizeof(line), fp))
        if (strlen(line) > 1) parseLine(line);
    fclose(fp);

    printOriginalQuadruples();
    constProp();
    printOptimizedQuadruples();
    return 0;
}